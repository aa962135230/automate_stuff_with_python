export default {
    path : '/mine',
    component : () => import('@/views/Mine')
}